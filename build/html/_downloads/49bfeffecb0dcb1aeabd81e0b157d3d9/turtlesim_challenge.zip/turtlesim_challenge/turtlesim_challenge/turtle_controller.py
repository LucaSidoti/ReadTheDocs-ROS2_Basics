import rclpy
from rclpy.node import Node

# -------------------------------
# TODO: Add required imports
# Example: messages (Twist, Pose), services (SetPen), partial from functools
# -------------------------------


class TurtleControllerNode(Node):

    def __init__(self):
        super().__init__("turtle_controller")

        # -------------------------------
        # TODO: Initialize attributes
        # Example: self.<attribute_name> = <initial_value>
        # -------------------------------

        # -------------------------------
        # TODO: Create subscribers
        # Example: self.create_subscription(<MsgType>, <topic_name>, <callback>, <queue_size>)
        # -------------------------------

        # -------------------------------
        # TODO: Create publishers
        # Example: self.create_publisher(<MsgType>, <topic_name>, <queue_size>)
        # -------------------------------

        # -------------------------------
        # TODO: Create timers
        # Example: self.create_timer(<interval_in_seconds>, <callback_function>)
        # -------------------------------

        self.get_logger().info("Turtle Controller Node has been started")


    # -------------------------------
    # TODO: Define callback methods
    # Example: def <callback_name>(self, msg):
    #              # Handle incoming message (e.g., update pose)
    # -------------------------------

    # -------------------------------
    # TODO: Define helper methods
    # Example: def <method_name>(self):
    #              # Implement logic (e.g., publish velocity, call service)
    # -------------------------------


def main(args=None):
    rclpy.init(args=args)
    node = TurtleControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
